# Horizon H1

An independent research project by Solomon Eshun: an editable architectural concept, reproducible synthetic system balances, and an interactive exhibit. H1 is personal early-stage work, with no physical installation or measured performance claimed.

## Run independently

Requires Node.js 22.13+ and Python 3. No API key, database, account or paid service is needed.

```sh
npm ci
npm run generate
npm test
npm run dev
```

The standalone preview opens at `http://127.0.0.1:4173`. `npm run build:preview` produces a static website in `preview-dist/`. `npm run build` produces the React package in `dist/`. Both run independently of the Horizon website.

## What is here

- `src/engine/`: typed state contract, timeline lookup, dataset validation and deterministic explanations. No Three.js dependency.
- `src/content/`: component identities, research rationale, assumptions and source links.
- `src/scene/`: Three.js presentation, semantic selection, cameras, cutaway, night lighting and system paths. No system physics.
- `src/H1Experience.tsx`, `src/style.css`: standalone React exhibit, responsive research inspector and accessible controls.
- `research/`: dependency-free Python generator, demonstration assumptions, research findings and validation roadmap.
- `model/horizon-h1.blend`: editable original semantic model, in metres.
- `model/build_h1.py`: reproducible Blender construction and GLB export.
- `assets/h1/`: deployable model, poster and scenario data.
- `tests/`: energy/water conservation, boundary conditions and explanation checks.
- `docs/`: architecture, authorship, source handling and verification records.

## Integrate a release into Horizon

```sh
npm run release:website -- ../horizon
```

The explicit release command builds and tests H1, creates a private local `.tgz` under the website's `vendor/`, installs that artifact, and copies web assets to `public/h1/`. It does not publish to npm or GitHub. The website imports `@horizon/h1` through a small client route adapter. It does not import files from this sibling folder.

The resulting Horizon checkout can deploy to Vercel by itself using `npm ci` and `npm run build`. Keep its `vendor/`, `vendor/h1-release.json`, `package-lock.json`, and `public/h1/` in version control. Do not add a `file:../horizon-h1` dependency. Increment H1's package version for subsequent published local releases; iteration within this initial unreleased 0.1.0 is supported by the release script.

To use H1 in another React host:

```tsx
import { H1Experience } from '@horizon/h1';
import '@horizon/h1/styles.css';

<H1Experience assetBaseUrl="/h1" backHref="/research" />
```

Copy `assets/h1` to the host's public `/h1` directory. In Next.js, import the experience through a client-only dynamic boundary. The host may provide `--font-sans` and `--font-serif`; the standalone preview has local font assets. There is no host router, environment-variable or stylesheet dependency in the package.

## Model editing

```sh
/Applications/Blender.app/Contents/MacOS/Blender -b --python model/build_h1.py
```

This regenerates `model/horizon-h1.blend`, `model/poster.png` and `assets/h1/models/horizon-h1.glb`. Save manual Blender edits under a different filename before rerunning. Re-export a WebP poster after visual review; the website build never launches Blender. Export uses original generic objects, semantic IDs in glTF extras and Y-up conversion. See `docs/ARCHITECTURE.md`.

## Research boundaries

The ten scenarios contain synthetic 15-minute intervals. All numeric displays are **Demo**. Energy and water conservation are tested; this does not validate selected equipment, local yield, thermal comfort, water quality or engineering feasibility. Temperature, humidity and CO₂ are scripted proxies. No EnergyPlus calculation, live sensor feed, tariff analysis, device control or external AI inference is included.

The guide reads structured state and returns bounded explanations. It does not send data to a language-model service. All functionality in this release uses free local tools and open-source runtime dependencies.

Original source and model rights are reserved. Dependency licenses remain intact. No remote repository has been created or published by this work.
